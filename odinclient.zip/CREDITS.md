We would like to express our gratitude to the following open-source projects, who have greatly aided us in the development of this mod:

- [Floppa Client](https://github.com/FloppaCoding/FloppaClient)
- [Skyblock Addons](https://github.com/BiscuitDevelopment/SkyblockAddons)
- [Skyblock Client](https://github.com/Harry282/Skyblock-Client)
- [Skytils](https://github.com/Skytils/SkytilsMod)
- [Water Solver](https://github.com/Desco1/WaterSolver)

Please feel free to use this project as inspiration, and copy parts of it, although credits are required by our license.
